<?php

namespace App\Http\Controllers;

use App\Models\Quiz;
use App\Http\Requests\StoreQuizRequest;
use App\Http\Requests\UpdateQuizRequest;
use Illuminate\Http\Request;
use App\Models\Question;
use App\Models\Answer;
use App\Models\AnswerTime;

class QuizController extends Controller
{
    public function index()
    {       
        $quizs = Question::with(['answers'])->get(); 
        $answer = Quiz::select('answer_id')->where('user_id',session()->get('user')->id)->get();
        $time = AnswerTime::first();
        $ids = [];
        foreach($answer as $a){
            $ids[] = $a->answer_id;
        }
        return view('quiz.index',compact('quizs','ids','time'));
    }

   
    public function store(Request $request)
    {            
        $answer = (!empty($request->answer)) ? $request->answer : [];
        Quiz::where('user_id',$request->user_id)->delete(); 
        foreach($answer as $k=>$v){
            $data['user_id'] = $request->user_id;
            $data['question_id'] = $k;
            $data['answer_id'] = $v;
            Quiz::create($data);
        }
        return redirect()->route('answer.result');
    }

   
    public function answer()
    {   
        $quizs = Question::with(['answers'])->get();
        $answer = Quiz::where('user_id',session()->get('user')->id)->get();   
        $ids = [];
        foreach($answer as $a){
            $ids[] = $a->answer_id;
        }
        $correct = Answer::where('is_correct',1)->whereIn('id',$ids)->count();
        
        return view('quiz.answer', compact('quizs','answer','correct'));
    }
}
    