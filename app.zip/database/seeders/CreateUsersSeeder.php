<?php

namespace Database\Seeders;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Crypt;

class CreateUsersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $users = [
            [
               'name'=>'Admin User',
               'email'=>'admin@gmail.com',
               'type'=>1,
               'password'=> Crypt::encryptString('123456'),
            ],
            [
               'name'=>'Suraj Sharma',
               'email'=>'suraj@gmail.com',
               'type'=> 0,
               'password'=> Crypt::encryptString('123456'),
            ],
            [
               'name'=>'User',
               'email'=>'user@gmail.com',
               'type'=>0,
               'password'=> Crypt::encryptString('123456'),
            ],
        ];
        
        foreach ($users as $key => $user) {
            User::create($user);
        }
    }
}
