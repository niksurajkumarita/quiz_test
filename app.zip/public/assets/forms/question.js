$(document).ready(function () {
    var tableUrl = $('.question-table').attr('url');
    $('.question-table').DataTable({
        aLengthMenu: [
            [10,25, 50, 100, 200, -1],
            [10,25, 50, 100, 200, "All"]
        ],
        processing: true,

        serverSide: true,

        "ordering": false,

        ajax: tableUrl,

        columns: [     
            { data: 'name', name: 'name' },
            { data: 'updated_at', name: 'updated_at' },
            {

                data: 'action',

                name: 'action',

                searchable: true

            },

        ]

    });
    var id = $('#ans-count').val();
    $('#add_more').click(function(){       
        id++;
        addAnswer(id);
    })

   $(".form").on("submit", function (event) {

        event.preventDefault();

        // if (validationForm()) {

            var action = $(this).attr('action');

            var fd = new FormData(this);

            $.ajax({

                url: action,

                type: "POST",

                data: fd,

                contentType: false,

                cache: false,

                processData: false,

                success: function (result) {

                    if (result.success == true) {

                        toastr['success']('data saved successfully...', 'Success !', {

                            closeButton: true,

                            tapToDismiss: false,

                        });

                        location.reload();

                    }

                    if (result.success == false) {
                        if (result.error[0]) {
                            $('.email-error').remove();
                            $('#email').after('<span class="text-danger email-error"><small>'+result.error[0]+'</small></span>');
                            flag = false;
                        } else {
                            $('.email-error').remove();
                        }
                        toastr['danger']('something went wrong...', 'Error !', {

                            closeButton: true,

                            tapToDismiss: false,

                        });

                    }

                }

            });

        // }

    });

    $('.is_correct_radio').change(function(){       
        var idd = $(this).attr('sno');       
        for(var i =1; i <= id; i++){          
            if(idd == i){
                $('#is_correct'+i).val(1);
            }else{
                $('#is_correct'+i).val(0);
            }            
        }
    })

});





$('.question-table').on('click', '.delete', function () {

    var delUrl = $(this).attr('url')

    Swal.fire({

        title: 'Are you sure?',

        text: "You won't be able to revert this!",

        icon: 'warning',

        showCancelButton: true,

        confirmButtonText: 'Yes, delete it!',

        customClass: {

            confirmButton: 'btn btn-primary',

            cancelButton: 'btn btn-outline-danger ms-1'

        },

        buttonsStyling: false

    }).then(function (result) {

        if (result.value) {

            $.ajax({

                url: delUrl,

                type: "DELETE",

                headers: {

                    'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')

                },

                success: function (result) {

                    if (result.success == true) {

                        Swal.fire({

                            icon: 'success',

                            title: 'Deleted!',

                            text: 'Your file has been deleted.',

                            customClass: {

                                confirmButton: 'btn btn-success'

                            }

                        });

                        $('.question-table').DataTable().ajax.reload();

                    }

                    if (result.success == false) {

                        Swal.fire({

                            icon: 'error',

                            title: 'Oops...',

                            text: 'Something went wrong!',

                            footer: '<a href>Why do I have this issue?</a>',

                            customClass: {

                                confirmButton: 'btn btn-primary'

                            },

                            buttonsStyling: false

                        });

                    }

                }

            });

        } else if (result.dismiss === Swal.DismissReason.cancel) {

            Swal.fire({

                title: 'Cancelled',

                text: 'Your imaginary file is safe :)',

                icon: 'error',

                customClass: {

                    confirmButton: 'btn btn-success'

                }

            });

        }

    });

})



function validationForm() {

    var user_image = $('#image').val();

    var name = $('#name').val();

    var email = $('#email').val();

    var password = $('#password').val();
    var flag = true;

     

    if (!name) {
        $('.name-error').remove();
        $('#name').after('<span class="text-danger name-error"><small>This fiels is required.</small></span>');
        flag = false;
    } else {
        $('.name-error').remove();
    }
    if (!password) {
        $('.password-error').remove();
        $('#password').after('<span class="text-danger password-error"><small>This fiels is required.</small></span>');
        flag = false;
    } else {
        $('.password-error').remove();
    }

    if (!email) {
        $('.email-error').remove();
        $('#email').after('<span class="text-danger email-error"><small>This fiels is required.</small></span>');
        flag = false;
    } else {
        $('.email-error').remove();
    }
    if($('#id') == ''){
        if (!user_image) {
            $('.image-error').remove();
            $('#image').after('<span class="text-danger image-error"><small>This fiels is required.</small></span>');
            flag = false;
        } else {
            $('.image-error').remove();
        }        
    }
    return flag;
}





function remove(row) {

    $('#row' + row).remove();

}



function clear() {

    $('#name').val('');

    $('#email').val('');

    $('#password').val('');

    $('#user_image').val('');

}

function addAnswer(id){
    var html = '';
    html = '<div id="row'+id+'" class="row">'+
                '<div class="col-md-6">'+
                    '<div class="mb-1">'+
                        '<label class="form-label" for="title">Answer </label>'+
                        '<input type="text" class="form-control" value="" id="answer" name="answer[]" placeholder="Answer" required />'+
                    '</div>'+
                '</div>'+
                '<div class="col-md-3">'+
                    '<div class="mt-3">'+
                        '<div class="form-check">'+
                            '<input type="radio" value="1" id="is_correct_radio" name="radio" sno="'+id+'" class="form-check-input is_correct_radio">'+
                            '<label class="form-check-label" for="category1">Check Answer</label>'+
                            '<input type="hidden" value="0" name="is_correct[]" id="is_correct'+id+'">'+
                        '</div>'+
                '</div>'+
                '</div>'+
                '<div class="col-md-3 mt-3">'+
                    '<button type="button" class="btn btn-sm btn-danger" onclick="remove('+id+')">X</button>'+
                '</div>'+
            '</div>';
    $('#answer-section').append(html);
    $('.is_correct_radio').change(function(){       
        var idd = $(this).attr('sno');       
        for(var i =1; i <= id; i++){          
            if(idd == i){
                $('#is_correct'+i).val(1);
            }else{
                $('#is_correct'+i).val(0);
            }            
        }
    })
}






