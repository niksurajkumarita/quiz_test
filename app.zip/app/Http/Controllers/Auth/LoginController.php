<?php

namespace App\Http\Controllers\Auth;
use Illuminate\Support\Facades\Crypt;
use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use App\Models\User;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    public function login(Request $request)
    {   
        $input = $request->all();
        $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);
        $user = User::where('type',0)->where('email', $request->input('email'))->first();
        $count = User::where('type',0)->where('email',$request->input('email'))->count();
        if($count > 0){
            if(Crypt::decryptString($user->password) == $request->password){
                $request->session()->put('user', $user);
                return redirect()->route('quiz.index')->with('status', 'login successfully'); 
            }else{                
                return redirect()->route('login')->with('error','Enter password is Wrong.');      
            }
        }else{          
            return redirect()->route('login')->with('error','Enter email address is Wrong.');
        } 
           
    }

    public function register(Request $request)
    {   
        $data = $request->all();
        $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
        ]);
        User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => Crypt::encryptString($data['password']),
        ]);
        return redirect()->route('login'); 
    }

    public function logout(Request $request){
        $request->session()->forget('user');       
        return redirect()->route('login');
    }
}
