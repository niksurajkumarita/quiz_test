<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Question;
use App\Models\Answer;
use App\Models\AnswerTime;
use DataTables;

class QuestionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $time = AnswerTime::first();
        return view('admin.question.list',compact('time'));        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // print_r(auth);
        return view('admin.question.create'); 
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {   
        if($request->id){
            $insert = Question::where('id',$request->id)->update(['name'=>$request->name]);
            Answer::where('question_id',$request->id)->delete();
            $insert_id = $request->id;
        }else{
            $insert = Question::create(['name'=>$request->name]);
            $insert_id = $insert->id;
        } 
        $answer = $request->answer;
        $is_correct = $request->is_correct;
        for($i =0 ; $i< count($answer); $i++){
            $data['question_id'] = $insert_id;
            $data['name'] = $answer[$i];
            $data['is_correct'] = $is_correct[$i];
            Answer::create($data);
        }

        // show messege
        if ($insert) {
            return response()->json(['success' => true]);
        } else {
            return response()->json(['success' => false]);
        }
     
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $id)
    {
        if ($request->ajax()) {
            $data = Question::latest()->get();           
            return DataTables::of($data)
                ->addIndexColumn()
                ->addColumn('action', function ($row) {
                    $url = route('question.destroy', $row->id);
                    $edit = route('question.edit', $row->id);
                    $actionBtn = '<a href="' . $edit . '" class="btn btn-primary btn-sm mt-1">Edit</a> <a href="javascript:void(0)"  url="' . $url . '" class="delete btn btn-danger btn-sm mt-1">Delete</a>';
                    return $actionBtn;
                })->editColumn('updated_at', function ($row) {
                    return date('d-m-Y h:i:s A', strtotime($row->updated_at));
                })->rawColumns(['action', 'type', 'updated_at'])
                ->make(true);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $que = Question::where('id',$id)->with(['answers'])->first(); 
        return view('admin.question.create', compact('que'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $deleted = Question::find($id)->delete();
        Answer::where('question_id',$id)->delete();
        if ($deleted) {
            return response()->json(['success' => true]);
        } else {
            return response()->json(['success' => false]);
        }
    }
    public function answer_time(Request $request)
    {
        $data['time'] = $request->time;
        AnswerTime::truncate();
        AnswerTime::create($data);        
        return redirect()->route('question.index');
    }
    
}
