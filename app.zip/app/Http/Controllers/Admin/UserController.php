<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Support\Facades\Crypt;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Validator;
use DataTables;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.user.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->except('_token');
        if(isset($request->password)){
            $data['password'] = bcrypt($data['password']);      
        }    

        if($request->id){
            $validator = Validator::make($request->all(), [
                'email' => 'required|unique:users'. ',email,' .$request->id,
            ]);
        }else{
            $validator = Validator::make($request->all(), [
                'email' => 'required|unique:users',
            ]);
        }
        if ($validator->passes()) {

            if ($user_image = $request->file('image')) {
                $name = time() . 'image.' . $request->file('image')->extension();
                $request->file('image')->move(public_path('uploads/user'), $name);
                $data['image'] = $name;
            }
            // insert or update
            if ($request->id) {
                unset($data['_token']);
                $data['updated_at'] = date('Y-m-d h:i:s');
                $insert =  User::where('id', $request->id)->update($data);
            } else {
                $insert = User::create($data);
            }
        }else{
            return response()->json(['success' => false,'error'=>$validator->errors()->all()]);
        }
        // show messege
        if ($insert) {
            return response()->json(['success' => true]);
        } else {
            return response()->json(['success' => false]);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $id)
    {
        if ($request->ajax()) {
            $data = User::latest()->get();           
            return DataTables::of($data)
                ->addIndexColumn()
                ->addColumn('action', function ($row) {
                    $url = route('user.destroy', $row->id);
                    $edit = route('user.edit', $row->id);
                    $actionBtn = '<a href="' . $edit . '" class="btn btn-primary btn-sm mt-1">Edit</a> <a href="javascript:void(0)"  url="' . $url . '" class="delete btn btn-danger btn-sm mt-1">Delete</a>';
                    return $actionBtn;
                })->editColumn('updated_at', function ($row) {
                    return date('d-m-Y h:i:s A', strtotime($row->updated_at));
                })->rawColumns(['action', 'type', 'updated_at'])
                ->make(true);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {      
        $user = User::where('id',$id)->first();   
        return view('admin.user.create', compact('user'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $deleted = User::find($id)->delete();
        if ($deleted) {
            return response()->json(['success' => true]);
        } else {
            return response()->json(['success' => false]);
        }
    }
}
