<?php

namespace App\Http\Controllers\Admin;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Crypt;
use App\Providers\RouteServiceProvider;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;

class AdminAuth extends Controller
{

    
    public function index(){
        return view('admin.login');
    }

    public function login(Request $request)
    { 
        $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);
        $user = User::where('type',1)->where('email', $request->input('email'))->first();
        $count = User::where('type',1)->where('email',$request->input('email'))->count();
        if($count > 0){
            if(Crypt::decryptString($user->password) == $request->password){
                $request->session()->put('admin_user', $user);
                return redirect()->route('admin.dashboard')->with('status', 'login successfully'); 
            }else{                
                return redirect()->back()->with(['error2'=>'enter password invalid','old_pass'=>$request->input('password')]);      
            }
        }else{          
            return redirect()->back()->with(['error1'=>'enter email invalid','old_email'=>$request->input('email')]);
        }           
    }

    public function dashboard(){
        return view('admin.user.list');
    }

    public function logout(Request $request){
        $request->session()->forget('admin_user');       
        return redirect()->route('admin.auth');
    }

    
}
